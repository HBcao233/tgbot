from html2image.browsers import chrome, chrome_cdp, edge  # , firefox, firefox_cdp
from html2image.browsers.browser import Browser, CDPBrowser
import time
import util


browser='chrome'


browser_map = {
    'chrome': chrome.ChromeHeadless,
    'chromium': chrome.ChromeHeadless,
    'google-chrome': chrome.ChromeHeadless,
    'googlechrome': chrome.ChromeHeadless,
    'edge': edge.EdgeHeadless,
    'chrome-cdp': chrome_cdp.ChromeCDP,
    'chromium-cdp': chrome_cdp.ChromeCDP,
    # 'firefox': firefox.FirefoxHeadless,
    # 'mozilla-firefox': firefox.FirefoxHeadless,
    # 'firefox-cdp': firefox_cdp.FirefoxCDP,
}
if browser.lower() not in browser_map:
    raise ValueError(
        f'"{browser}" is not a browser known by HTML2Image.'
    )
browser_class = browser_map[browser.lower()]
if isinstance(browser_class, CDPBrowser):
    browser = browser_class(
        executable=browser_executable,
        flags=custom_flags,
        cdp_port=browser_cdp_port,
        disable_logging=disable_logging,
    )
else:
    browser = browser_class(
        executable=browser_executable,
        flags=custom_flags,
        disable_logging=disable_logging,
    )
    
    
def screenshot(html='', size=(1920, 1080)):
  file = util.getCache(int(time.perf_counter() * 1000))
  with open(file, 'wb') as f:
    f.write(content.encode('utf-8'))
  
  res = browser.screenshot(
    output=self.output_path,
    input=file,
    size=size,
  )
  os.remove(file)
  return res